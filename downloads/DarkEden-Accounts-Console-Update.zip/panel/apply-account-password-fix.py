#!/usr/bin/env python3
from pathlib import Path

app_path = Path("panel/web/app.py")
template_path = Path("panel/web/templates/panel.html")
app = app_path.read_text()
template = template_path.read_text()
old = '''    if not re.fullmatch("[A-Za-z0-9]{4,10}", player) or not re.fullmatch("[A-Za-z0-9]{6,10}", password):
        raise ValueError("Use 4–10 letters or digits for the ID and 6–10 for the password.")'''
new = '''    try:
        password_bytes = password.encode("latin1")
    except UnicodeEncodeError:
        password_bytes = b""
    if not re.fullmatch("[A-Za-z0-9]{4,10}", player) or not (6 <= len(password_bytes) <= 10 and all(32 <= byte <= 126 and byte not in (39, 92) for byte in password_bytes)):
        raise ValueError("Use a 4–10 character player ID. Game passwords must be 6–10 printable characters; apostrophe and backslash are not allowed.")'''
if app.count(old) != 1:
    raise SystemExit("Expected new-account password check was not found exactly once; no files changed.")
start = template.find('<form method="post" action="/account">')
end = template.find("</form>", start)
if start < 0 or end < 0:
    raise SystemExit("New-account form was not found; no files changed.")
form = template[start:end]
old_html = 'pattern="[a-zA-Z0-9]{6,10}"'
new_html = 'minlength="6" maxlength="10" pattern="[^\'\\\\]{6,10}" title="6–10 printable characters; apostrophe and backslash are not allowed."'
if form.count(old_html) != 1:
    raise SystemExit("Expected new-account password field rule was not found exactly once; no files changed.")
updated_form = form.replace(old_html, new_html, 1)
updated_template = template[:start] + updated_form + template[end:]
app_path.write_text(app.replace(old, new, 1))
template_path.write_text(updated_template)
print("Updated only new-account password validation. Existing panel features were left untouched.")
