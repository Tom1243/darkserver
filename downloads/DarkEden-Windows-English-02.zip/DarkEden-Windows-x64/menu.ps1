$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$stateDir = Join-Path $env:LOCALAPPDATA 'OpenDarkEden'
[void](New-Item -ItemType Directory -Force $stateDir)
$settings = Join-Path $stateDir 'client.txt'
$serverHistory = Join-Path $stateDir 'servers.txt'
$compose = Join-Path $PSScriptRoot 'server\standalone\compose.yaml'
function Stack([string[]]$Arguments) {
    if (!(Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Install and start Docker Desktop with Linux containers to host a world.' }
    & docker compose -f $compose @Arguments
    if ($LASTEXITCODE) { throw 'Docker failed. See the accompanying console for details.' }
}
function Address {
    $ip = $address.Text.Trim()
    $parsed = $null
    if ($ip -notmatch '^(\d{1,3}\.){3}\d{1,3}$' -or ![Net.IPAddress]::TryParse($ip,[ref]$parsed)) { throw 'Enter a valid IPv4 address.' }
    return $ip
}
function RememberAddress([string]$ip) {
    $saved = @()
    if (Test-Path -LiteralPath $serverHistory) {
        $saved = @(Get-Content -LiteralPath $serverHistory | Where-Object { $_ -and $_.Trim() })
    }
    $addresses = @($ip) + @($saved | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne $ip })
    $addresses = @($addresses | Select-Object -Unique | Select-Object -First 20)
    [IO.File]::WriteAllLines($serverHistory,[string[]]$addresses,[Text.Encoding]::UTF8)
    $address.BeginUpdate()
    $address.Items.Clear()
    foreach ($savedIp in $addresses) { [void]$address.Items.Add($savedIp) }
    $address.EndUpdate()
    $address.Text = $ip
}
function LaunchGame {
    $ip = Address
    RememberAddress $ip
    $dir = if (Test-Path $settings) { Get-Content -LiteralPath $settings -Raw }
    if (!$dir -or !(Test-Path -LiteralPath (Join-Path $dir 'fengshen.exe'))) {
        $pick = New-Object Windows.Forms.OpenFileDialog
        $pick.Title = 'Select fengshen.exe from your extracted DARKEDEN game folder'
        $pick.Filter = 'Dark Eden client|fengshen.exe'
        if ($pick.ShowDialog() -ne 'OK') { return }
        $dir = Split-Path $pick.FileName
        [IO.File]::WriteAllText($settings,$dir)
    }
    $originalHashes = @{
        'Data/Ui/spk/GameMenuSlayer.spk' = '52249182d96f2bc39bb5d0815d119801df3cfae67240624e67f4db67fc9b51b5'
        'Data/Ui/spk/GameMenuSlayer.spki' = '6353c2fc633eb2b1e3685beb8ab99a56faa8d8fa7a52f2d543e7e1179982f66b'
        'Data/Ui/spk/GameMenuVampire.spk' = 'fb5791ec827f2ab65c54d9a059097030c8141a8712b56911544fbab1a20a1ff8'
        'Data/Ui/spk/GameMenuVampire.spki' = '4d30a0964781380e0c819effbc9df23ad325fee3afd19e62327cf79b096cd225'
        'Data/Ui/spk/GameMenuOusters.spk' = 'b83f273a020ee0c0cac5000230947413d806767dab4a1dd26d23d97e372ca7bd'
        'Data/Ui/spk/GameMenuOusters.spki' = 'de0fbb8a87ef8ae9fa27c1e9a2b3382da76fab44d5d2810dc989877f96a40908'
        'Data/Ui/spk/OptionSlayer.spk' = '34207b9030d22ca35a88d0792dba169d593f0c90dfa23c114c3e30836f219899'
        'Data/Ui/spk/OptionSlayer.spki' = '50a4ff1f9eeffb502d181219ee48fc5cd5442ea7106e8c219b31d9ea811cdf4f'
        'Data/Ui/spk/OptionVampire.spk' = 'f49b88da07a75ce1823a94347fdc41dd76395dbc6180c87c900471a3e0daf14a'
        'Data/Ui/spk/OptionVampire.spki' = '167f443d48dbb6000e2806dd0c9c33e15b5327fd9c7f540f5205f1e8b59b7fe0'
        'Data/Ui/spk/OptionOusters.spk' = '1ec04ef87b84bdd3b90d51311f77375e1f4b3c080daa8f1f5cb8bf5a23db19ee'
        'Data/Ui/spk/OptionOusters.spki' = '698c270680f68477ee9e812953e313cea29352ef27d68c9a77a7297421509d6b'
        'Data/Ui/txt/Help.rpk' = '034b4dc4942cc0ac24684c9ec640e78761ff7e46af67b44bdb53e0a8df851d8c'
        'Data/Ui/txt/TutorialEtc.rpk' = '659cead0726c67a26f2a49df69fec28a932283ed5017e93e1b9849d61d2cbe43'
        'Data/Ui/txt/item.rpk' = 'ac023b87c29ab1a7668d9696aa513bf3f839b706956b8f34cd6e6eacd28abec1'
        'Data/Ui/txt/skill.rpk' = '2a2a0d1774e75c9485be6ce08979f50a343260cde8681a805283285dbf725521'
        'Data/Ui/txt/Book.rpk' = 'aa47c5888a785e503cf85a197326f028f5629ccf00c995f259e4cb73728de3e4'
        'Data/Ui/txt/progress.rpk' = '5f499ba7e777c3ef3ba0cadd2affc05ef014b5a993354db8259a32f7bb85a96d'
        'Data/Info/NPC.inf' = 'c08b04d75239cdd8bfd381d7d77631b8af8ef6871f9e4f3139ee4111ceb8331a'
        'Data/Info/NPCScript.inf' = '0bd70e78cbf038442c7852a9b435a86bf597b4adc26606e8a7563ee7f69d9e4e'
        'Data/Info/Help.inf' = 'e78379964b6404cc3a688ec3e3b2252aff2ac333b7b30e698aa1ce18c5f99e13'
        'Data/Ui/txt/title.rpk' = '2f546635bf59cf5f2653b3562014a1f8ab9f0f2aaea70d2612562f14bf68f214'
        'Data/Ui/spk/ServerSelect.spk' = '318fde5188b7b43eb60245288ac57c6e3c0f7083dbcde7453dd4d417df93ce10'
    }
    foreach ($name in $originalHashes.Keys) {
        $target = Join-Path $dir $name
        if ((Test-Path -LiteralPath $target) -and (Get-FileHash -LiteralPath $target).Hash -eq $originalHashes[$name]) {
            $source = Join-Path (Join-Path $PSScriptRoot 'English') $name
            $temp = "$target.$([guid]::NewGuid()).tmp"
            try {
                Copy-Item -LiteralPath $source -Destination $temp
                [IO.File]::Replace($temp,$target,"$target.before-English")
            } finally {
                if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp }
            }
        }
    }
    $file = Join-Path $dir 'Data\Info\GameClient.inf'
    $enc = [Text.Encoding]::GetEncoding(28591)
    $original = [IO.File]::ReadAllText($file,$enc)
    $key = '(?im)^(\s*LoginServerAddress\d*\s*[:=]\s*)[^\s#;]+'
    if ($original -notmatch $key) { throw 'This GameClient.inf has no recognized LoginServerAddress setting.' }
    $updated = [regex]::Replace($original,$key,('${1}'+$ip))
    $updated = [regex]::Replace($updated,'(?im)^(\s*LoginServerPort\s*[:=]\s*)\d+','${1}9999')
    $updated = [regex]::Replace($updated,'(?im)^(\s*LoginServerPortNum\s*[:=]\s*)\d+','${1}1')
    if ($updated -cne $original) {
        if (!(Test-Path "$file.original")) { Copy-Item -LiteralPath $file -Destination "$file.original" }
        [IO.File]::WriteAllText($file,$updated,$enc)
    }
    # Use the client's own launcher script so this path behaves exactly like
    # double-clicking window.bat (which can set up launch details for this build).
    $batch = Join-Path $dir 'window.bat'
    if (Test-Path -LiteralPath $batch) {
        Start-Process -FilePath $env:ComSpec -WorkingDirectory $dir -WindowStyle Hidden -ArgumentList '/d','/c','window.bat'
    } else {
        Start-Process -FilePath (Join-Path $dir 'fengshen.exe') -WorkingDirectory $dir -ArgumentList '0000000001'
    }
}
$form = New-Object Windows.Forms.Form
$form.Text = 'Dark Eden'
$form.ClientSize = New-Object Drawing.Size(420,360)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
function Label($text,$y) {
    $label = New-Object Windows.Forms.Label
    $label.Text = $text
    $label.SetBounds(20,$y,382,22)
    $form.Controls.Add($label)
}
function Button($text,$x,$y,$width,$action) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text
    $b.SetBounds($x,$y,$width,34)
    $b.Tag = $action
    $b.Add_Click({ param($sender,$event)
        try { $action = $sender.Tag; & $action } catch { [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Dark Eden') }
    })
    $form.Controls.Add($b)
}
Label 'Server IPv4 address (use 127.0.0.1 for solo play)' 20
$address = New-Object Windows.Forms.ComboBox
$address.DropDownStyle = [Windows.Forms.ComboBoxStyle]::DropDown
$address.SetBounds(20,45,380,28)
if (Test-Path -LiteralPath $serverHistory) {
    foreach ($savedIp in (Get-Content -LiteralPath $serverHistory | Where-Object { $_ -and $_.Trim() })) { [void]$address.Items.Add($savedIp.Trim()) }
}
if ($address.Items.Count) { $address.SelectedIndex = 0 } else { $address.Text = '127.0.0.1' }
$form.Controls.Add($address)
Button 'Play / join world' 20 85 380 { LaunchGame }
Label 'Host a world on this PC' 144
Button 'Start server' 20 170 185 {
    $env:DARKEDEN_IP = Address
    RememberAddress $env:DARKEDEN_IP
    $env:DARKEDEN_BIND = if ($env:DARKEDEN_IP -eq '127.0.0.1') { '127.0.0.1' } else { '0.0.0.0' }
    Stack @('up','-d','--wait')
    [void][Windows.Forms.MessageBox]::Show('World ready. Create a player, then choose Play.','Dark Eden')
}
Button 'Stop server' 215 170 185 { Stack @('down') }
Button 'Create player' 20 215 380 {
    $name = $player.Text
    $pass = $secret.Text
    if ($name -cnotmatch '^[a-zA-Z0-9]{4,10}$' -or $pass -cnotmatch '^[a-zA-Z0-9]{6,10}$') { throw 'Use 4-10 letters or digits for the ID and 6-10 for the password.' }
    @($name,$pass) | docker compose -f $compose exec -T odk-mysql bash /opt/darkeden-admin add-player
    if ($LASTEXITCODE) { throw 'Could not create player. Check the server is running and choose an unused ID.' }
    $secret.Clear()
    [void][Windows.Forms.MessageBox]::Show('Player created.','Dark Eden')
}
Label 'Player ID                                   Game password' 263
$player = New-Object Windows.Forms.TextBox
$secret = New-Object Windows.Forms.TextBox
$player.SetBounds(20,286,185,28)
$secret.SetBounds(215,286,185,28)
$secret.UseSystemPasswordChar = $true
$form.Controls.AddRange(@($player,$secret))
[void]$form.ShowDialog()
