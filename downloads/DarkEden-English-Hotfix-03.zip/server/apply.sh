#!/bin/bash
set -eu
root=$(realpath "$(dirname "$0")")
archive=panel/live/source.tar.gz
test -f "$archive" || { echo "Run from the World Admin compose directory."; exit 1; }
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir "$tmp/source"
tar xzf "$archive" -C "$tmp/source"
target=src/server/gameserver/EffectGDRLairClose.cpp
if ! cmp -s "$tmp/source/$target" "$root/EffectGDRLairClose.cpp"; then
    sha256sum "$tmp/source/$target" | grep -q '^24c573f0bdfff77be7b31ade2472971006db7c6f86f65591e847136458d622d0 ' || { echo "Unrecognized source version."; exit 1; }
    cp "$root/EffectGDRLairClose.cpp" "$tmp/source/$target"
    tar czf "$tmp/new.tgz" -C "$tmp/source" .
    cp -n "$archive" "$archive.before-english"
    cp "$tmp/new.tgz" "$archive.tmp"
    mv "$archive.tmp" "$archive"
fi
docker build --platform linux/amd64 -t darkeden-world-admin-game:local panel/live
if [[ -f panel/private/live-enabled ]]; then
    docker compose up -d --no-deps --wait game
else
    echo "Image built. Enable live controls through panel setup to activate it."
fi
