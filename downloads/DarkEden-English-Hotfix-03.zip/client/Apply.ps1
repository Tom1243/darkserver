﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$d=New-Object Windows.Forms.OpenFileDialog
$d.Filter='Dark Eden client|fengshen.exe'
if($d.ShowDialog() -ne 'OK'){exit}
if(Get-Process fengshen -ErrorAction SilentlyContinue){throw 'Close the game first.'}
$game=Split-Path $d.FileName
$catalog=Get-Content "$PSScriptRoot/letters.json" -Raw | ConvertFrom-Json
function Install-Bytes($path,[byte[]]$bytes){
    $tmp="$path.$([guid]::NewGuid()).tmp"
    try {
        [IO.File]::WriteAllBytes($tmp,$bytes)
        [IO.File]::Replace($tmp,$path,"$path.$([guid]::NewGuid()).bak")
    } finally {if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp}}
}
$pack=Join-Path $game 'Data/Ui/txt/Help.rpk'
$new=Join-Path $PSScriptRoot Help.rpk
$hash=(Get-FileHash -LiteralPath $pack).Hash
if($hash -ne (Get-FileHash $new).Hash){
    if($hash -notin @('034b4dc4942cc0ac24684c9ec640e78761ff7e46af67b44bdb53e0a8df851d8c','881e75998790650537d205d2e9100b48f405994b05f62eb4765455be29dba0c1')){throw 'Unknown Help.rpk version.'}
    Install-Bytes $pack ([IO.File]::ReadAllBytes($new))
}
foreach($file in Get-ChildItem (Join-Path $game UserSet) -Filter '*.mail'){
 $r=[IO.BinaryReader]::new([IO.MemoryStream]::new([IO.File]::ReadAllBytes($file.FullName)))
 $out=[IO.MemoryStream]::new();$w=[IO.BinaryWriter]::new($out)
 try{
    if($r.ReadUInt32() -ne 0 -or $r.ReadByte() -ne 2){throw 'Unknown format'}
    $w.Write([uint32]0);$w.Write([byte]2)
    for($tab=0;$tab -lt 2;$tab++){
      $n=$r.ReadUInt32();$w.Write($n)
      for($i=0;$i -lt $n;$i++){
        $id=$r.ReadUInt32();$w.Write($id);$w.Write($r.ReadByte())
        $fields=@{}
        for($j=0;$j -lt 4;$j++){
          $len=$r.ReadInt32()
          if($len -lt 0 -or $len -gt $r.BaseStream.Length-$r.BaseStream.Position){throw 'Invalid field'}
          $fields[$j]=$r.ReadBytes($len)
        }
        if($tab -eq 1 -and $id -lt $catalog.Count){
          $sender=[Text.Encoding]::GetEncoding(949).GetString($fields[0])
          $race=switch -Regex ($sender){'^(Kaiser|카이저)' {0;break} '^(Lavinia|라비니아)' {2;break} '^(Vrykolakas|브리|브루|브이)' {1;break} default {-1}}
          if($race -ge 0){$page=$catalog[$id][$race]}else{$page=$null}
          if($page){$j=0;foreach($v in @($page.sender,$page.title,$page.body)){$fields[$j]=[Text.Encoding]::ASCII.GetBytes($v);$j++}}
        }
        for($j=0;$j -lt 4;$j++){ $w.Write([int]$fields[$j].Length);$w.Write([byte[]]$fields[$j]) }
        $w.Write($r.ReadInt64())
      }
    }
    if($r.BaseStream.Position -ne $r.BaseStream.Length){throw 'Unexpected trailing data'}
    $w.Flush()
    if([Convert]::ToBase64String($out.ToArray()) -ne [Convert]::ToBase64String([IO.File]::ReadAllBytes($file.FullName))){Install-Bytes $file.FullName $out.ToArray()}
 } catch {Write-Warning ("Skipped "+$file.Name+" - "+$_.Exception.Message)} finally {$r.Dispose();$w.Dispose();$out.Dispose()}
}
Write-Host 'English Help installed.'
