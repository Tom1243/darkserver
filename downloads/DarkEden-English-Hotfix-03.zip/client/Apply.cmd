@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply.ps1"
pause
