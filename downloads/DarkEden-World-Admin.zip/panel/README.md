# Dark Eden world administration

Extract the panel directory alongside compose.yaml in your existing standalone installation. On Unraid run `bash panel/setup.sh` from that directory. The existing MySQL service must be running. Pick the server's LAN IP and a free HTTPS port. The installer prints the administrator password and the fingerprint for the local certificate. Inspect that fingerprint when accepting the browser's certificate warning. To retrieve your password later, run `cat panel/private/password`. Keep panel/private on the server.

Character and account tools work with the stock server. Search by exact account ID or character name. Log out completely to edit. A level edit sets base level (a domain level for Slayers) and resets progress within that level. This is an administrative override and does not award the stats, skills or points for playing through those levels. Login messages appear as system messages. They use a different route from the client's mail window.

For immediate XP changes or announcements, answer y to the live-controls build. It compiles the bundled server source with two build jobs. Docker needs network access for Ubuntu build packages, Python dependencies and base images. Build time depends on CPU, memory and disk. The running game can stay up while it builds. When ready, log everyone out, then accept the switch. The installer restores the stock game if the new process fails its readiness check. The database volume stays attached to MySQL throughout. Back up your world before testing a different game executable. The live image uses the fork's game source at 3f183364a60c535f9b1d036107e94d584a604b54, with the original image's login server, shared server, assets and configuration. In-game compatibility with your client must be verified on your installation.

Rates are percentages. 100 is normal and 200 is double for that setting. Multiple experience modifiers can affect the same award. Reload the page to see the latest acknowledgement and saved database values. Broadcast sends a system message to connected players. A disconnect during delivery can leave its outcome unknown.

To switch back later, log players out and run `bash panel/setup.sh --stock`. For logs use `docker compose logs --tail=100 admin game`.

If you already use a custom Compose override, merge the admin service in panel/compose.panel into it, replacing __IP__ and __PORT__. The installer normally generates the password, key and certificate shown in setup.sh. Merge the game block from panel/compose.game only after building the live image. Preserve your existing game mounts.

## Panel tabs

World applies settings in the running game. Loot changes affect future rolls. HP and damage settings apply when the game next calculates those stats. War registration fees apply to future registrations. Items edits the base price for an item type across the world. Restart the game after saving item prices. Characters edits logged-out accounts and can queue a login message. Accounts creates player logins. Settings index lists stored values, including settings managed by events and the war scheduler.

To upgrade, extract over the previous panel folder and run the setup script again. Rebuild and switch the live game image to enable the new commands.
