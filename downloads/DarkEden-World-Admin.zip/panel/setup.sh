#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f compose.yaml && -f ../initdb/a-setup.sql ]] || { echo "Extract the panel folder inside the existing standalone folder."; exit 1; }
command -v openssl >/dev/null
override=compose.override.yaml
marker='# Dark Eden world panel'
for f in compose.override.yml docker-compose.override.yml docker-compose.override.yaml; do
    [[ ! -e $f ]] || { echo "Existing override $f detected. See panel/README.md for manual integration."; exit 1; }
done
[[ ! -e $override || $(head -1 "$override") == "$marker" ]] || { echo "Preserving your existing override. See panel/README.md."; exit 1; }
umask 077
mkdir -p panel/private panel/bridge
default_ip=$(sed -n 's/^DARKEDEN_IP=//p' .env 2>/dev/null | tail -1 || true)
if [[ -f panel/private/address ]]; then read -r default_ip default_port < panel/private/address; fi
read -rp "Panel LAN IPv4 address [${default_ip:-127.0.0.1}]: " ip
ip=${ip:-${default_ip:-127.0.0.1}}
[[ $ip =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ && $ip != 0.0.0.0 ]] || { echo "Enter one local IPv4 address."; exit 2; }
IFS=. read -ra octets <<< "$ip"
for n in "${octets[@]}"; do ((10#$n <= 255)) || exit 2; done
read -rp "Panel HTTPS port [${default_port:-8787}]: " port
port=${port:-${default_port:-8787}}
[[ $port =~ ^[1-9][0-9]{0,4}$ ]] && (( port <= 65535 )) || exit 2
if [[ ! -s panel/private/password ]]; then openssl rand -hex 20 > panel/private/password; fi
if [[ ! -s panel/private/cert.pem || ! -s panel/private/key.pem ]] || ! openssl x509 -in panel/private/cert.pem -noout -checkip "$ip" | grep -q 'does match'; then
    openssl req -x509 -newkey rsa:2048 -nodes -days 825 -subj "/CN=$ip" -addext "subjectAltName=IP:$ip" -keyout panel/private/key.tmp -out panel/private/cert.tmp
    mv panel/private/key.tmp panel/private/key.pem
    mv panel/private/cert.tmp panel/private/cert.pem
fi
printf '%s %s\n' "$ip" "$port" > panel/private/address
temp=$(mktemp ./panel-override-XXXXXX)
trap 'rm -f "$temp"' EXIT
sed "s/__IP__/$ip/g;s/__PORT__/$port/g" panel/compose.panel > "$temp"
# Persist live mode across reconfiguration.
if [[ -f panel/private/live-enabled ]]; then cat panel/compose.game >> "$temp"; fi
docker compose -f compose.yaml -f "$temp" config -q
mv "$temp" "$override"
docker compose up -d --no-deps --build admin
docker compose exec -T admin python -c 'import app; db=app.database(); cur=db.__enter__(); cur.execute("SELECT COUNT(*) FROM Player"); db.__exit__(None,None,None)'
echo "Open https://$ip:$port  (username admin)"
echo "Panel password: $(cat panel/private/password)"
openssl x509 -in panel/private/cert.pem -noout -fingerprint -sha256
if [[ ${1:-} == --stock ]]; then
    rm -f panel/private/live-enabled
    sed "s/__IP__/$ip/g;s/__PORT__/$port/g" panel/compose.panel > "$override"
    docker compose up -d --no-deps --wait game
    exit
fi
read -rp "Build the live-controls game image now? The current game stays up during the build [y/N] " build
[[ $build == [yY] ]] || exit 0
docker build --platform linux/amd64 -t darkeden-world-admin-game:local panel/live
read -rp "Have all players logged out? Switch the game container to live controls now [y/N] " switch
[[ $switch == [yY] ]] || exit 0
sed "s/__IP__/$ip/g;s/__PORT__/$port/g" panel/compose.panel > "$temp"
cat panel/compose.game >> "$temp"
mv "$temp" "$override"
touch panel/private/live-enabled
if docker compose up -d --no-deps --wait game; then
    for ((i=0; i<60; i++)); do
        if docker compose exec -T admin python -c 'import app; exit(0 if app.live() else 1)'; then
            echo "Live game controls ready."; exit 0
        fi
        sleep 2
    done
fi
echo "Live game did not become ready. Restoring the stock game."
docker compose logs --tail=40 game || true
rm -f panel/private/live-enabled
sed "s/__IP__/$ip/g;s/__PORT__/$port/g" panel/compose.panel > "$override"
docker compose up -d --no-deps --wait game
exit 1
