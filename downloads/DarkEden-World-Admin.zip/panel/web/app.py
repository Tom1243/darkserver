import fcntl
import hmac
import os
import re
import secrets
import time
from contextlib import contextmanager
from pathlib import Path

import pymysql
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for

app = Flask(__name__)
token = Path("/private/password").read_text().strip()
app.secret_key = hmac.digest(token.encode(), b"session key", "sha256")
app.config.update(MAX_CONTENT_LENGTH=8192, SESSION_COOKIE_SECURE=True, SESSION_COOKIE_SAMESITE="Strict", SESSION_COOKIE_HTTPONLY=True)
bridge = Path("/run/world-admin")
schema = Path("/private/setup.sql").read_text()
db_password = re.search(r"CREATE USER 'elcastle'@'%' IDENTIFIED BY '([^']+)'", schema)[1]
domains = ["Blade", "Sword", "Gun", "Heal", "Enchant"]
rates = {'xp': (4, 'General XP (%)', 100, 9999999), 'pet': (81, 'Pet XP (%)', 1, 9999999), 'monster': (105, 'Monster XP (%)', 1, 9999999), 'event': (1, 'Event bonuses (0 off, 1 on)', 0, 1), 'rank': (37, 'Rank XP (%)', 0, 10000), 'drop': (3, 'Item drop multiplier (%)', 100, 10000), 'rare': (17, 'Additional item option chance multiplier (%)', 0, 10000), 'unique': (18, 'Unique item roll (out of 10,000)', 0, 10000), 'fee': (47, 'War registration fee (gold)', 0, 9999999), 'slayerhp': (101, 'Slayer maximum HP (%)', 1, 10000), 'oustershp': (103, 'Ousters maximum HP (%)', 1, 10000), 'vampirehp': (102, 'Vampire maximum HP (%)', 1, 10000), 'monsterhp': (104, 'Monster maximum HP (%)', 1, 10000), 'damage': (108, 'Monster damage (%)', 1, 10000)}
setting_names = ['STAR_RATIO', 'EVENT_ACTIVE', 'EVENT_RATIO', 'ITEM_PROBE_RATIO', 'EXP_RATIO', 'COMBAT_BONUS_TIME', 'COMBAT_SLAYER_HP_BONUS_RATIO', 'COMBAT_VAMPIRE_HP_BONUS_RATIO', 'PREMIUM_EXP_BONUS_PERCENT', 'PREMIUM_ITEM_PROBE_PERCENT', 'ZONE_GROUP_BALANCING_MINUTE', 'GAMBLE_ITEM_TYPE_RATIO', 'GAMBLE_ITEM_OPTION_RATIO', 'SUMMON_MOTORCYCLE', 'ENEMY_LIMIT_TIME', 'COMBAT_SLAYER_DAMAGE_BONUS', 'COMBAT_VAMPIRE_DAMAGE_BONUS', 'RARE_ITEM_RATIO', 'UNIQUE_ITEM_RATIO', 'ACTIVE_MASTER_LAIR', 'RETRY_MASTER_LAIR', 'HARVEST_FESTIVAL_ITEM_RATIO', 'MASTER_BLOOD_DRAIN_START_HP', 'MASTER_BLOOD_DRAIN_START_BD', 'MASTER_BLOOD_DRAIN_END_HP', 'MASTER_BLOOD_DRAIN_END_BD', 'ACTIVE_CHIEF_MONSTER', 'CHIEF_MONSTER_RARE_ITEM_RATIO', 'NEWBIE_TRANSPORT_TO_GUILD', 'FREE_PLAY_SLAYER_DOMAIN_SUM', 'FREE_PLAY_VAMPIRE_LEVEL', 'LOG_INCOMING_CONNECTION', 'CHRISTMAS_FIRE_CRACKER_RATIO', 'CHRISTMAS_TREE_PART_RATIO', 'CHRISTMAS_GIFT_BOX_RATIO', 'CHRISTMAS_TREE_DECAY_TIME', 'MASTER_LAIR_PLAYER_NUM', 'RANK_EXP_GAIN_PERCENT', 'ITEM_LUCK_PERCENT', 'LOTTO_ITEM_RATIO', 'LOTTO_ITEM_BONUS_NUM', 'LOTTO_SKULL_RATIO', 'PREMIUM_HALF_EVENT', 'COMMON_CASTLE_ENTRANCE_FEE', 'GUILD_CASTLE_ENTRANCE_FEE', 'COMMON_CASTLE_ITEM_TAX_RATIO', 'GUILD_CASTLE_ITEM_TAX_RATIO', 'WAR_REGISTRATION_FEE', 'GUILD_WAR_TIME', 'RACE_WAR_TIME', 'WAR_PERIOD_WEEK', 'WAR_ACTIVE', 'RACE_WAR_TIMEBAND', 'AUTO_START_RACE_WAR', 'ACTIVE_RACE_WAR_LIMITER', 'CHIEF_ITEM_BONUS_NUM', 'ACTIVE_EVENT_GIVE_ITEM', 'VAMPIRE_REDISTRIBUTE_ATTR_PRICE', 'ACTIVATE_COUPLE', 'CAN_RECOUPLE', 'GUILD_WAR_ACTIVE', 'FREE_PLAY_OUSTERS_LEVEL', 'CAN_APPLY_QUEST', 'SEND_QUEST_INFO', 'CAN_BUY_SHOP', 'PCROOM_EXP_BONUS', 'PCROOM_ITEM_RATIO_BONUS', 'MONEY_TRACE_LOG_LIMIT', 'PC_ROOM_LOTTO_EVENT', 'ACTIVE_FLAG_WAR', 'KILL_DAEMONCTL', 'EVENT_MOON_CARD', 'FULL_MOON_CARD_RATIO', 'HALF_MOON_CARD_RATIO', 'NEW_MOON_CARD_RATIO', 'OLD_MOON_CARD_RATIO', 'ACTIVE_LEVEL_WAR', 'RACE_WAR_HP_BONUS', 'HEAD_COUNT', 'HEAD_PRICE_BONUS', 'LEVEL_WAR_ZONE_FREE_ENTER', 'PET_EXP_RATIO', 'EVENT_LUCKY_BAG', 'GREEN_LUCKY_BAG_RATIO', 'BLUE_LUCKY_BAG_RATIO', 'GOLD_LUCKY_BAG_RATIO', 'RED_LUCKY_BAG_RATIO', 'EVENT_GIFT_BOX', 'RED_GIFT_BOX_RATIO', 'BLUE_GIFT_BOX_RATIO', 'GREEN_GIFT_BOX_RATIO', 'YELLOW_GIFT_BOX_RATIO', 'NETMARBLE_CARD_RATIO', 'NETMARBLE_CARD_EVENT', 'PREMIUM_TRIAL_EVENT', 'PET_FOOD_EVENT', 'HIGHER_PET_FOOD_RATIO', 'PET_FOOD_RATIO', 'RACE_PET_FOOD_RATIO', 'REVIVAL_SET_RATIO', 'TODAY_IS_HOLYDAY', 'SLAYER_HP_RATIO', 'VAMPIRE_HP_RATIO', 'OUSTERS_HP_RATIO', 'MONSTER_HP_RATIO', 'MONSTER_EXP_RATIO', 'CLOVER_EVENT', 'CLOVER_RATIO', 'MONSTER_DAMAGE_RATIO', 'RACE_PET_QUEST', 'NICKNAME_PEN_EVENT', 'NICKNAME_PEN_RATIO', 'GOLD_MEDAL_RATIO', 'PET_DAY_EVENT', 'OLYMPIC_ITEM_RATIO', 'OLYMPIC_EVENT', 'CROWN_PRICE', 'CHOBO_EVENT', 'PINE_CAKE_EVENT', 'PINE_CAKE_RATIO', 'QUIT_GUILD_PENALTY_TERM', 'GUILD_UNION_MAX', 'LUCK_CHARM_RATIO', 'GDR_LAIR_PC_LIMIT', 'DONATION_EVENT_200501', 'HOURGLASS_RATIO_S', 'HOURGLASS_RATIO_M', 'HOURGLASS_RATIO_L', 'EVENT_NEW_YEAR_2005', 'BOKJORY_RATIO', 'EVENT_RED_RICE_CAKE_SOUP_RATIO', 'EVENT_GREEN_RICE_CAKE_SOUP_RATIO', 'EVENT_BLUE_RICE_CAKE_SOUP_RATIO', 'EVENT_BLACK_RICE_CAKE_SOUP_RATIO', 'EVENT_MUGWORT_RICE_CAKE_SOUP_RATIO', 'TIME_PERIOD_EXP_2X', 'VARIABLE_MAX']
item_tables = ['ARInfo', 'BeltInfo', 'BladeInfo', 'BloodBibleInfo', 'BombInfo', 'BombMaterialInfo', 'BraceletInfo', 'CarryingReceiverInfo', 'CastleSymbolInfo', 'CoatInfo', 'CodeSheetInfo', 'ComposMeiInfo', 'CoreZapInfo', 'CoupleRingInfo', 'CrossInfo', 'DermisInfo', 'DyePotionInfo', 'ETCInfo', 'EffectItemInfo', 'EventETCInfo', 'EventGiftBoxInfo', 'EventItemInfo', 'EventStarInfo', 'EventTreeInfo', 'FasciaInfo', 'GQuestItemInfo', 'GloveInfo', 'HelmInfo', 'HolyWaterInfo', 'KeyInfo', 'LarvaInfo', 'LearningItemInfo', 'LuckyBagInfo', 'MaceInfo', 'MagazineInfo', 'MineInfo', 'MittenInfo', 'MixingItemInfo', 'MoonCardInfo', 'MotorcycleInfo', 'NecklaceInfo', 'OustersArmsbandInfo', 'OustersBootsInfo', 'OustersChakramInfo', 'OustersCircletInfo', 'OustersCoatInfo', 'OustersPendentInfo', 'OustersRingInfo', 'OustersStoneInfo', 'OustersSummonItemInfo', 'OustersWristletInfo', 'PersonaInfo', 'PetEnchantItemInfo', 'PetFoodInfo', 'PetItemInfo', 'PotionInfo', 'PupaInfo', 'QuestItemInfo', 'RelicInfo', 'ResurrectItemInfo', 'RingInfo', 'SGInfo', 'SMGInfo', 'SMSItemInfo', 'SRInfo', 'SerumInfo', 'ShieldInfo', 'ShoesInfo', 'ShoulderArmorInfo', 'SkullInfo', 'SlayerPortalItemInfo', 'SubInventoryInfo', 'SweeperInfo', 'SwordInfo', 'TrapItemInfo', 'TrouserInfo', 'VampireAmuletInfo', 'VampireBraceletInfo', 'VampireCoatInfo', 'VampireCoupleRingInfo', 'VampireETCInfo', 'VampireEarringInfo', 'VampireNecklaceInfo', 'VampirePortalItemInfo', 'VampireRingInfo', 'VampireWeaponInfo', 'WarItemInfo', 'WaterInfo']
races = ("Slayer", "Vampire", "Ousters")


@app.before_request
def authorize():
    auth = request.authorization
    if not auth or auth.username != "admin" or not hmac.compare_digest((auth.password or "").encode(), token.encode()):
        return "Sign in with the panel credentials.", 401, {"WWW-Authenticate": 'Basic realm="Dark Eden"'}
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(24)
    if request.method == "POST" and not hmac.compare_digest(request.form.get("csrf", "").encode(), session["csrf"].encode()):
        abort(403)


@app.after_request
def headers(response):
    response.headers.update({"Cache-Control": "no-store", "X-Frame-Options": "DENY",
                             "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'"})
    return response


@contextmanager
def database():
    conn = pymysql.connect(host="odk-mysql", user="elcastle", password=db_password, database="DARKEDEN",
                           charset="latin1", connect_timeout=4, read_timeout=8, write_timeout=8,
                           cursorclass=pymysql.cursors.DictCursor)
    try:
        with conn.cursor() as cur:
            yield cur
        conn.commit()
    finally:
        conn.close()


@app.errorhandler(pymysql.MySQLError)
def database_error(error):
    code = error.args[0]
    return f"Database request failed (MySQL {int(code)}). Reload the panel to check the saved value.", 503


@app.errorhandler(ValueError)
def invalid(error):
    return render_template("error.html", message=str(error)), 400


def fields(race):
    return ["Gold", "StashGold", "Fame", "Bonus"] + (["SkillBonus"] if race == "Ousters" else []) + ([d + "Level" for d in domains] if race == "Slayer" else ["Level"])


def live():
    try:
        heartbeat = bridge / "heartbeat"
        return time.time() - heartbeat.stat().st_mtime < 10 and heartbeat.read_text().strip() == "2"
    except FileNotFoundError:
        return False


@app.get("/")
def index():
    query = request.args.get("q", "").strip()[:20]
    results = []
    with database() as cur:
        cur.execute("SELECT attrID,attr1 FROM AttrInfo ORDER BY attrID")
        values = {r["attrID"]: r["attr1"] for r in cur.fetchall()}
        tab = request.args.get("tab", "Characters" if query else "World")
        category = request.args.get("category", "SwordInfo")
        items = []
        if tab == "Items" and category in item_tables:
            cur.execute(f"SELECT ItemType,EName,Price FROM {category} ORDER BY ItemType")
            items = cur.fetchall()
        if query and tab == "Characters":
            for race in races:
                columns = ",".join(fields(race))
                cur.execute(f"SELECT c.Name, c.PlayerID, p.LogOn,{columns} FROM {race} c JOIN Player p ON p.PlayerID=c.PlayerID WHERE c.Active='ACTIVE' AND (c.Name=%s OR c.PlayerID=%s) LIMIT 30", (query, query))
                results.extend((race, row) for row in cur.fetchall())
    reply = bridge / "reply"
    return render_template("panel.html", rates=rates, tab=tab, categories=item_tables, category=category, items=items, setting_names=setting_names, values=values, live=live(), q=query, results=results,
                           fields=fields, reply=reply.read_text().strip() if reply.exists() else "")


def text_message(value):
    if not re.fullmatch(r"[ -~]{1,160}", value) or not value.strip():
        raise ValueError("Enter 1–160 printable English characters.")
    return value


@app.post("/world")
def world():
    op = request.form["op"]
    value = request.form["value"].strip()
    if op == "notice":
        text_message(value)
    elif op in rates and value.isascii() and value.isdecimal() and len(value) <= 7:
        if not rates[op][2] <= int(value) <= rates[op][3]:
            raise ValueError("Value is outside the supported range.")
    else:
        raise ValueError("Invalid world setting.")
    if not live():
        raise ValueError("The game is offline or the live controls have not been installed.")
    with (bridge / "lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if any((bridge / n).exists() for n in ("request", "processing")):
            raise ValueError("A command is in progress. Refresh before trying again.")
        ident = secrets.token_hex(5)
        tmp = bridge / "request.tmp"
        tmp.write_text(f"{ident}\n{op}\n{value}\n")
        os.replace(tmp, bridge / "request")
    flash(f"Submitted {ident}. Refresh to see the game’s acknowledgement.")
    return redirect(url_for("index"), 303)


@app.post("/character")
def character():
    form = request.form
    race, name, owner = form["race"], form["name"], form["owner"]
    if race not in races:
        abort(400)
    with database() as cur:
        cur.execute("SELECT LogOn FROM Player WHERE PlayerID=%s FOR UPDATE", (owner,))
        account = cur.fetchone()
        if not account:
            abort(404)
        cur.execute(f"SELECT {','.join(fields(race))} FROM {race} WHERE Name=%s AND PlayerID=%s AND Active='ACTIVE' FOR UPDATE", (name, owner))
        row = cur.fetchone()
        if not row:
            abort(404)
        if form["field"] == "message":
            if len(name.encode("latin1")) > 10:
                raise ValueError("This character name exceeds the game's message receiver limit.")
            cur.execute("INSERT INTO Messages (Receiver,Sender,Message) VALUES (%s,'Admin',%s)", (name, text_message(form["value"])))
            flash("Message queued for the character’s next login.")
        else:
            if account["LogOn"] != "LOGOFF":
                raise ValueError("Log out of the game completely before editing this account.")
            field = form["field"]
            if field not in fields(race) or not re.fullmatch(r"[0-9]{1,10}", form["value"]):
                raise ValueError("Invalid character field or amount.")
            if str(row[field]) != form["old"]:
                raise ValueError("The saved value changed. Reload the character before editing.")
            value = int(form["value"])
            if field.endswith("Level"):
                if not 1 <= value <= 150:
                    raise ValueError("Choose a base level from 1 to 150.")
                if race == "Slayer" and value > row[field]:
                    total = sum(row[d + "Level"] for d in domains) - row[field] + value
                    if total > 150:
                        raise ValueError("The combined Slayer domain levels would exceed 150.")
                prefix = field[:-5]
                if race == "Slayer":
                    cur.execute("SELECT GoalExp FROM SkillDomainInfo WHERE DomainType=%s AND Level=%s", (domains.index(prefix), value))
                else:
                    table = "VampEXPBalanceInfo" if race == "Vampire" else "OustersEXPBalanceInfo"
                    cur.execute(f"SELECT GoalExp FROM {table} WHERE Level=%s", (value,))
                balance = cur.fetchone()
                if not balance or balance["GoalExp"] <= 0:
                    raise ValueError("No usable experience entry for that level.")
                cur.execute(f"UPDATE {race} SET {field}=%s,{prefix}GoalExp=%s,{prefix}Exp=0 WHERE Name=%s", (value, balance["GoalExp"], name))
            else:
                limit = 32767 if field in ("Bonus", "SkillBonus") else 2000000000
                if value > limit:
                    raise ValueError(f"{field} must be between 0 and {limit:,}.")
                cur.execute(f"UPDATE {race} SET {field}=%s WHERE Name=%s", (value, name))
            flash(f"Saved {name}’s {field}.")
    return redirect(url_for("index", q=owner), 303)


@app.post("/account")
def account():
    player, password = request.form["player"], request.form["password"]
    if not re.fullmatch("[A-Za-z0-9]{4,10}", player) or not re.fullmatch("[A-Za-z0-9]{6,10}", password):
        raise ValueError("Use 4–10 letters or digits for the ID and 6–10 for the password.")
    with database() as cur:
        try:
            cur.execute("INSERT INTO Player (PlayerID,Password,Name,CurrentWorldID,CurrentServerGroupID,PayType,creation_date) VALUES (%s,%s,%s,1,0,0,CURDATE())", (player,password,player))
        except pymysql.IntegrityError as e:
            if e.args[0] != 1062:
                raise
            raise ValueError("That player ID is taken.") from None
    flash("Player account created.")
    return redirect(url_for("index"), 303)

@app.post("/price")
def price():
    category = request.form["category"]
    if category not in item_tables:
        abort(400)
    item, old, new = (int(request.form[key]) for key in ("item", "old", "new"))
    if not 0 <= new <= 2000000000:
        raise ValueError("Price must be between zero and two billion.")
    if old != new:
        with database() as cur:
            cur.execute(f"UPDATE {category} SET Price=%s WHERE ItemType=%s AND Price=%s", (new,item,old))
            if cur.rowcount != 1:
                raise ValueError("Item price changed. Refresh before saving.")
    flash("Base price saved. Restart the game server to reload item definitions.")
    return redirect(url_for("index", tab="Items", category=category), 303)
