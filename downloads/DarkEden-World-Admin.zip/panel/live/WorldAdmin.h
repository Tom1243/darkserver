#pragma once
#include "GCSystemMessage.h"
#include <fstream>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <unistd.h>
#include <string>

// Only the game and admin containers mount this directory.
static void pollWorldAdmin(long now) {
    static long next = 0;
    if (now < next) return;
    next = now + 2;
    const std::string root = "/run/world-admin/";
    if (access(root.c_str(), W_OK) != 0) return;
    static bool initialized = false;
    if (!initialized) {
        // On startup, an interrupted command has an unknown delivery status.
        if (access((root+"processing").c_str(), F_OK) == 0 || access((root+"request").c_str(), F_OK) == 0) {
            std::ofstream(root+"reply") << "Game restarted during a command. Verify before retrying.";
            std::remove((root+"processing").c_str());
            std::remove((root+"request").c_str());
        }
        initialized = true;
    }
    { std::ofstream heartbeat(root+"heartbeat.tmp"); heartbeat << "2\n"; }
    std::rename((root+"heartbeat.tmp").c_str(), (root+"heartbeat").c_str());
    std::ifstream input(root + "request");
    std::string id, op, arg;
    if (!std::getline(input, id) || !std::getline(input, op) || !std::getline(input, arg)) return;
    // Claim before broadcasting. Never replay a notice after a crash.
    if (std::rename((root+"request").c_str(), (root+"processing").c_str()) != 0) return;
    std::string outcome = "Rejected";
    try {
        if (op == "notice" && !arg.empty() && arg.size() <= 160 && arg.find_first_not_of(
            " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&'()*+,-./:;<=>?@[\\]^_`{|}~\"") == std::string::npos) {
            GCSystemMessage msg;
            msg.setMessage(arg);
            g_pZoneGroupManager->broadcast(&msg);
            outcome = "Broadcast";
        } else if (arg.size() <= 7 && !arg.empty() && arg.find_first_not_of("0123456789") == std::string::npos) {
            int value = std::atoi(arg.c_str());
            struct Setting { const char* key; VariableType type; int low; int high; };
            static const Setting settings[] = {
                {"xp", EXP_RATIO, 100, 9999999},
                {"pet", PET_EXP_RATIO, 1, 9999999},
                {"monster", MONSTER_EXP_RATIO, 1, 9999999},
                {"event", EVENT_ACTIVE, 0, 1},
                {"rank", RANK_EXP_GAIN_PERCENT, 0, 10000},
                {"drop", ITEM_PROBE_RATIO, 100, 10000},
                {"rare", RARE_ITEM_RATIO, 0, 10000},
                {"unique", UNIQUE_ITEM_RATIO, 0, 10000},
                {"fee", WAR_REGISTRATION_FEE, 0, 9999999},
                {"slayerhp", SLAYER_HP_RATIO, 1, 10000},
                {"oustershp", OUSTERS_HP_RATIO, 1, 10000},
                {"vampirehp", VAMPIRE_HP_RATIO, 1, 10000},
                {"monsterhp", MONSTER_HP_RATIO, 1, 10000},
                {"damage", MONSTER_DAMAGE_RATIO, 1, 10000},
            };
            for (const Setting& setting : settings) {
                if (op == setting.key && value >= setting.low && value <= setting.high) {
                    g_pVariableManager->setVariable(setting.type, value);
                    if (g_pVariableManager->getVariable(setting.type) == value) outcome = "Applied in game";
                    break;
                }
            }
        }
    } catch (...) { outcome = "Game reported an error"; }
    { std::ofstream out(root+"reply.tmp"); out << id << " " << outcome << '\n'; }
    std::rename((root+"reply.tmp").c_str(), (root+"reply").c_str());
    std::remove((root+"processing").c_str());
}
