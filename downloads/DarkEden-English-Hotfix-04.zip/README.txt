Dark Eden English Hotfix 04
===========================

This bundle includes the server lair notice from Hotfix 03, the Hotfix 03
client mail/help files, and English translations for legacy player notices,
server text pools, alliance/team/guild messages, and untranslated system
messages found in the bundled live server source.

Server install
--------------
1. Have all players log out.
2. Extract this ZIP into the World Admin compose directory (the directory that
   contains the panel/ folder and compose.yaml).
3. From that directory, run:

   bash server/apply.sh

The script updates the server source archive, builds the live-controls game
image once, updates the existing database string pools, and restarts the game
only if live controls are already enabled. The source archive is backed up as
panel/live/source.tar.gz.before-hotfix-04. If the source version is not the
expected one, the script stops before modifying it.

A full Docker image build is required because the server notices are compiled
into the game server. The normal live server stays up while Docker builds the
new image; the game restarts after the build completes if live controls are
active.

Client mail/help patch
----------------------
The client/ files are carried forward from Hotfix 03. On each Windows client,
run client/Apply.cmd as described in client/Apply.ps1. That client patch is
separate from the server command above.
