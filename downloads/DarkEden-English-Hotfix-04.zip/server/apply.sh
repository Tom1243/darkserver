#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$(dirname "$0")/..")
archive="$root/panel/live/source.tar.gz"
[[ -f "$archive" ]] || { echo "Extract Hotfix 04 into the World Admin compose directory and run it from there."; exit 1; }
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir "$tmp/source"
tar xzf "$archive" -C "$tmp/source"
# Validate every source file before changing the archive, so a different source
# version is never silently overwritten.
while read -r expected relative; do
    target="$tmp/source/$relative"
    patch="$root/server/patches/$relative"
    [[ -f "$target" && -f "$patch" ]] || { echo "Missing source file: $relative"; exit 1; }
    if cmp -s "$target" "$patch"; then continue; fi
    actual=$(sha256sum "$target" | cut -d ' ' -f1)
    [[ "$actual" == "$expected" ]] || { echo "Unrecognized source version at $relative; no source changes were applied."; exit 1; }
done < "$root/server/manifest.sha256"
while read -r expected relative; do
    cp "$root/server/patches/$relative" "$tmp/source/$relative"
done < "$root/server/manifest.sha256"
tar czf "$tmp/source.new.tgz" -C "$tmp/source" .
cp -n "$archive" "$archive.before-hotfix-04"
cp "$tmp/source.new.tgz" "$archive.tmp"
mv "$archive.tmp" "$archive"
docker build --platform linux/amd64 -t darkeden-world-admin-game:local "$root/panel/live"
docker compose exec -T odk-mysql mysql -uelcastle -pelca110 DARKEDEN < "$root/server/english-string-pool.sql"
if [[ -f "$root/panel/private/live-enabled" ]]; then
    docker compose up -d --no-deps --wait game
else
    echo "Image built and message text updated. Enable live controls through panel setup to activate the patched server source."
fi
