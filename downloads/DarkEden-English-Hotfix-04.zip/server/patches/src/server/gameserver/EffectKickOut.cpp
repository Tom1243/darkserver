#include "EffectKickOut.h"

#include <cstdio>

#include "GCSystemMessage.h"
#include "PCManager.h"
#include "Zone.h"

void EffectKickOut::affect() {
    // 1분에 한번
    setNextTime(600);
    m_MinutesCount--;

    char msg[200];
    sprintf(msg, "This area will close in %d minutes.", m_MinutesCount);
    GCSystemMessage gcSM;
    gcSM.setMessage(msg);
    m_pZone->broadcastPacket(&gcSM);
}

void EffectKickOut::unaffect() {
    __BEGIN_TRY

    GCSystemMessage gcSM;
    gcSM.setMessage("This area is closing. You will be returned to the entrance in 10 minutes.");
    m_pZone->broadcastPacket(&gcSM);

    if (m_pZone != NULL)
        m_pZone->getPCManager()->transportAllCreatures(0xffff);

    __END_CATCH
}
